void main() {
  String isim ="Engin";
  print("Merhaba "+isim);

  int sayi = 10;
  double ucret = 10.5;
  print("Sayı = "+ sayi.toString());
  print("Ücret = "+ ucret.toString());

  bool dogruMu = 100>200;
  print(dogruMu);

}